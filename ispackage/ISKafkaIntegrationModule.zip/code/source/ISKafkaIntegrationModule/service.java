package ISKafkaIntegrationModule;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-07-06 15:32:08 IST
// -----( ON-HOST: MCSDAS02.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.gcs.lib.ISKafkaIntegration.*;
import com.softwareag.util.IDataMap;
// --- <<IS-END-IMPORTS>> ---

public final class service

{
	// ---( internal utility methods )---

	final static service _instance = new service();

	static service _newInstance() { return new service(); }

	static service _cast(Object o) { return (service)o; }

	// ---( server methods )---




	public static final void createConsumer (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createConsumer)>> ---
		// @sigtype java 3.5
		// [i] field:0:required name
		// [i] field:0:required bootstrapServers
		// [i] field:0:required topicName
		// [i] field:0:required clientGroupId
		// [i] field:0:required enableAutoCommit
		// [i] field:0:required autoCommitIntervalInMs
		// [i] field:0:required sessionTimeOut
		// [i] field:0:required serviceName
		IDataMap pipelineMap = new IDataMap(pipeline);
		
		String name = pipelineMap.getAsString("name");
		String bootstrapServers = pipelineMap.getAsString("bootstrapServers");
		String topicName = pipelineMap.getAsString("topicName");
		String clientGroupId = pipelineMap.getAsString("clientGroupId");
		String enableAutoCommit = pipelineMap.getAsString("enableAutoCommit");
		Integer autoCommitIntervalInMs = pipelineMap.getAsInteger("autoCommitIntervalInMs");
		Integer sessionTimeOut = pipelineMap.getAsInteger("sessionTimeOut");
		String serviceName = pipelineMap.getAsString("serviceName");
		
		WmKafkaConsumer wmKafkaConsumer = new WmKafkaConsumer();
		wmKafkaConsumer.createConsumer(topicName,bootstrapServers,clientGroupId,enableAutoCommit, autoCommitIntervalInMs , sessionTimeOut , serviceName , name);
			
		// --- <<IS-END>> ---

                
	}



	public static final void createProducer (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createProducer)>> ---
		// @sigtype java 3.5
		// [i] field:0:required bootstrapServers
		// [i] field:0:required retries
		// [i] field:0:required acks
		// [i] field:0:required batchSize
		// [i] field:0:required lingerInMs
		// [i] field:0:required bufferMem
		// [i] field:0:required Untitled
		// [o] field:0:required status
		// [o] field:0:required message
		IDataMap pipelineMap = new IDataMap(pipeline);
		String bootstrapServers = pipelineMap.getAsString("bootstrapServers" );
		Integer retries  = pipelineMap.getAsInteger("retries" );
		String acks = pipelineMap.getAsString("acks");
		Integer batchSize = pipelineMap.getAsInteger("batchSize");
		Integer lingerInMs = pipelineMap.getAsInteger("lingerInMs");
		Integer bufferMem = pipelineMap.getAsInteger("bufferMem");
		
		wmKafkaProducer = new WmKafkaProducer(bootstrapServers, retries, acks, batchSize, lingerInMs, bufferMem) ;
		
		pipelineMap.put("status", "true");
		pipelineMap.put("message", "Producer created successfully with provided parameters");
			
		// --- <<IS-END>> ---

                
	}



	public static final void sendData (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sendData)>> ---
		// @sigtype java 3.5
		// [i] field:0:required topicName
		// [i] field:0:required keyName
		// [i] record:0:required value
		// [i] field:0:required callBackService
		// [o] field:0:required status
		IDataMap pipelineMap = new IDataMap(pipeline);
		
		  String topicName = pipelineMap.getAsString("topicName");
		  String keyName = pipelineMap.getAsString("keyName");
		  IData value = pipelineMap.getAsIData("value");
		  String callBackService = pipelineMap.getAsString("callBackService");
		  
		  wmKafkaProducer.send(topicName, keyName, value, callBackService);
			
		// --- <<IS-END>> ---

                
	}



	public static final void stopConsumer (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stopConsumer)>> ---
		// @sigtype java 3.5
		// [i] field:0:required name
		IDataMap pipeMap = new IDataMap(pipeline);
		WmKafkaConsumer.close(pipeMap.getAsString("name"));
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	static WmKafkaProducer wmKafkaProducer ;
	// --- <<IS-END-SHARED>> ---
}

